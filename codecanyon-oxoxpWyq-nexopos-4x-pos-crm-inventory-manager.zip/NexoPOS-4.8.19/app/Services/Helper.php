<?php

namespace App\Services;

use App\Services\Helpers\App;
use App\Services\Helpers\ArrayHelper;

class Helper
{
    use ArrayHelper,
        App;
}
