module.exports = {
  content: [
    "./Resources/**/*.blade.php",
    "./Resources/**/*.js",
    "./Resources/**/*.ts",
    "./Resources/**/*.vue",
  ],
  prefix: 'go-',
  theme: {
    extend: {},
  },
  plugins: [],
}
