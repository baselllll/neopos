<?php

namespace Modules\NsGastro\Tests\Feature;

use Tests\Feature\ConfigureAccoutingTest;

class GastroConfigureAccountingTest extends ConfigureAccoutingTest
{
    // ...
}
