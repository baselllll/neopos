<?php

namespace Modules\NsGastro\Tests\Feature;

use Tests\Feature\CreateTaxGroupTest;

class GastroCreateTaxGroupTest extends CreateTaxGroupTest
{
    // ...
}
