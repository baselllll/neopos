<?php

namespace Modules\NsGastro\Tests\Feature;

use Tests\Feature\CreateProviderTest;

class GastroCreateProviderTest extends CreateProviderTest
{
    // ...
}
